<div class="well widget">
	<div class="header">
		View Highscores
	</div>
	<div class="body">
		<form action="highscores.php" method="get">
			<select name="type">
				<option value="7">Experience</option>
				<option value="5">Shielding</option>
				<option value="3">Axe</option>
				<option value="2">Sword</option>
				<option value="1">Club</option>
				<option value="4">Distance</option>
				<option value="9">Fist</option>
				<option value="6">Fish</option>
				<option value="8">Magic</option>
			</select>
			<input type="submit" value="Fetch scoreboard">
		</form>
	</div>
</div>